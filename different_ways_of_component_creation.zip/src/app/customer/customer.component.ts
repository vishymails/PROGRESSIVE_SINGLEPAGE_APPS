import { style } from '@angular/animations';
import { Component } from '@angular/core';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styles : [

  ]
})
export class CustomerComponent {

}
