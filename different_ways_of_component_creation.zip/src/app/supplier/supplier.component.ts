import { Component } from '@angular/core';

@Component({
  selector: 'app-supplier',
  template : `
  <p> Supplier Component </p>`,
  styleUrls: ['./supplier.component.css']
})
export class SupplierComponent {

}
