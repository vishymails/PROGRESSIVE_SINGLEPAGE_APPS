import { Component } from '@angular/core';

@Component({
  selector: 'app-associate',
  template : `
  <p> Associate Component 
  </p>`,
  styles :[
    
  ]
})
export class AssociateComponent {

}
